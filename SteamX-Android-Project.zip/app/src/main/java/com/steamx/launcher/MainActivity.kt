package com.steamx.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF171A21)
private val Panel = Color(0xFF202631)
private val Blue = Color(0xFF66C0F4)
private val Muted = Color(0xFF9AA4B2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SteamXApp() }
    }
}

@Composable
fun SteamXApp() {
    var tab by remember { mutableStateOf("Library") }
    var selected by remember { mutableStateOf("Poppy Playtime") }
    val games = listOf("Poppy Playtime", "Grand Theft Auto V", "Minecraft", "Roblox")

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Blue,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(Modifier.fillMaxSize().background(Bg).padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("STEAM", color = Blue, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(" X", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.weight(1f))
                Text("S26 ULTRA", color = Muted, fontSize = 11.sp)
            }
            Spacer(Modifier.height(24.dp))
            Text(tab.uppercase(), color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            when (tab) {
                "Library" -> {
                    Text("Your games", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(14.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(games) { game ->
                            Row(
                                Modifier.fillMaxWidth()
                                    .background(if (selected == game) Color(0xFF26394A) else Panel, RoundedCornerShape(14.dp))
                                    .clickable { selected = game }
                                    .padding(18.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(42.dp).background(Color(0xFF34465A), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                                    Text(game.take(1), color = Blue, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                                }
                                Spacer(Modifier.width(14.dp))
                                Column {
                                    Text(game, fontWeight = FontWeight.SemiBold)
                                    Text(if (selected == game) "Selected" else "Ready to configure", color = Muted, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("SELECTED GAME", color = Muted, fontSize = 11.sp)
                    Text(selected, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Launcher preview. Game runtime integration is not included yet.", color = Muted, fontSize = 12.sp)
                }
                "Performance" -> {
                    Text("Performance", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    InfoTile("Performance profiles", "Balanced • Performance • Battery saver")
                    InfoTile("Graphics options", "Per-game settings will be added in a later build")
                    InfoTile("Device monitoring", "Live CPU/GPU readings require supported system access")
                }
                else -> {
                    Text("Settings", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    InfoTile("Appearance", "Steam-inspired dark interface")
                    InfoTile("About Steam X", "Version 1.0 • Early preview")
                    InfoTile("No ads. No account.", "A simple launcher interface.")
                }
            }
            Spacer(Modifier.weight(1f))
            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                listOf("Library", "Performance", "Settings").forEach { item ->
                    Text(
                        item,
                        color = if (tab == item) Blue else Muted,
                        fontWeight = if (tab == item) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.clickable { tab = item }.padding(horizontal = 9.dp, vertical = 13.dp),
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun InfoTile(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(bottom = 10.dp).background(Panel, RoundedCornerShape(14.dp)).padding(16.dp)) {
        Text(title, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(5.dp))
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}
