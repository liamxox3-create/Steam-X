STEAM X - ANDROID PREVIEW

This is an early UI preview, not a PC game emulator or GameHub replacement.
It does not yet launch Windows games, change GPU drivers, or provide live CPU/GPU telemetry.

Build:
- JDK 17
- Android SDK platform 35
- Gradle 8.9
- Run: gradle assembleDebug

APK output:
app/build/outputs/apk/debug/app-debug.apk
